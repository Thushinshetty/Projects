"""trydjango URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from hms import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',include('hms.urls')),
    path('dept',views.dept),
    path('show',views.show),
    path('edit/<int:dept_cabin>',views.edit),
    path('update/<int:dept_cabin>',views.update),
    path('delete/<int:dept_cabin>',views.delete),



    path('pat',views.pat),
    path('show1',views.show1),
    path('edit1/<int:patient_id>',views.edit1),
    path('update1/<int:patient_id>',views.update1),
    path('delete1/<int:patient_id>',views.delete1),

    path('sta',views.sta),
    path('show2',views.show2),
    path('edit2/<int:s_id>',views.edit2),
    path('update2/<int:s_id>',views.update2),
    path('delete2/<int:s_id>',views.delete2),

    path('app',views.app),
    path('show3',views.show3),
    path('edit3/<int:app_id>',views.edit3),
    path('update3/<int:app_id>',views.update3),
    path('delete3/<int:app_id>',views.delete3),

    path('bi',views.bi),
    path('show4',views.show4),
    path('edit4/<int:invoice>',views.edit4),
    path('update4/<int:invoice>',views.update4),
    path('delete4/<int:invoice>',views.delete4),
]
