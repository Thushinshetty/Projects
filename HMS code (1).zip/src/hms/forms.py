from django import forms
from hms.models import department
from hms.models import patient
from hms.models import staff
from hms.models import appointment
from hms.models import bill

class departmentForm (forms.ModelForm):
    class Meta:
        model = department 
        fields = "__all__"

class patientForm (forms.ModelForm):
    class Meta:
        model = patient
        fields = "__all__"

class staffForm (forms.ModelForm):
    class Meta:
        model = staff
        fields = "__all__"

class appointmentForm (forms.ModelForm):
    class Meta:
        model = appointment
        fields = "__all__"

class billForm (forms.ModelForm):
    class Meta:
        model = bill
        fields = "__all__"