
from django.shortcuts import render,redirect
from hms.forms import departmentForm
from hms.models import department
from hms.forms import patientForm
from hms.models import patient
from hms.forms import staffForm
from hms.models import staff
from hms.forms import appointmentForm
from hms.models import appointment
from hms.forms import billForm
from hms.models import bill
from django.http import HttpResponse

def login_form(request):
    return render(request,'login.html')

def submit_form(request):
    username = request.GET['username']
    password = request.GET['password']
    if{username == 'admin' and password = "user"}

def dept(request):
    if request.method == "POST":
        form = departmentForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                return redirect("/show")
            except:
                pass
    else:
        form = departmentForm()
        return render(request,"dept.html",{'form':form})

def show(request):
    departments = department.objects.all()
    return render(request,"show.html",{'departments': departments})

def edit(request, dept_cabin):
    departmentt = department.objects.get(dept_cabin=dept_cabin)
    return render(request,"edit.html",{'departmentt' : departmentt})

def update(request, dept_cabin):
    departmentt = department.objects.get(dept_cabin=dept_cabin)
    form = departmentForm(request.POST, instance = departmentt)
    if form.is_valid():
        form.save()
        return redirect('/show')
    return render(request,"edit.html",{'departmentt' : departmentt})
def delete(request, dept_cabin):
    departmentt = department.objects.get(dept_cabin=dept_cabin) 
    departmentt.delete()
    return redirect("/show")

# patient__________________________________________________________________________________________________

def pat(request):
    if request.method == "POST":
        form = patientForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                return redirect("/show1")
            except:
                pass
    else:
        form = patientForm()
        return render(request, "patient.html", {'form':form})

def show1(request):
    patients = patient.objects.all()
    return render(request,"show1.html",{'patients': patients})

def edit1(request, patient_id):
    patientt = patient.objects.get(patient_id=patient_id)
    return render(request,"edit1.html",{'patientt' : patientt})
def update1(request, patient_id):
    patientt = patient.objects.get(patient_id=patient_id)
    form = patientForm(request.POST, instance = patientt)
    if form.is_valid():
        form.save()
        return redirect('/show1')
    return render(request,"edit1.html",{'patientt' : patientt})
def delete1(request, patient_id):
    patientt = patient.objects.get(patient_id=patient_id)
    patientt.delete()
    return redirect("/show1")

#staff______________________________________________________________________________________________________

def sta(request):
    if request.method == "POST":
        form = staffForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                return redirect("/show2")
            except:
                pass
    else:
        form = staffForm()
        return render(request, "staff.html", {'form':form})

def show2(request):
    staffs = staff.objects.all()
    return render(request,"show2.html",{'staffs': staffs})

def edit2(request, s_id):
    stafft = staff.objects.get(s_id=s_id)
    return render(request,"edit2.html",{'stafft' : stafft})
def update2(request, s_id):
    stafft = staff.objects.get(s_id=s_id)
    form = staffForm(request.POST, instance = stafft)
    if form.is_valid():
        form.save()
        return redirect('/show2')
    return render(request,"edit2.html",{'stafft' : stafft})
def delete2(request, s_id):
    stafft = staff.objects.get(s_id=s_id)
    stafft.delete()
    return redirect("/show2")

#appoi__________________________________________________________________________________________________________

def app(request):
    if request.method == "POST":
        form = appointmentForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                return redirect("/show3")
            except:
                pass
    else:
        form = appointmentForm()
        return render(request,"app.html",{'form':form})

def show3(request):
    appointments = appointment.objects.all()
    return render(request,"show3.html",{'appointments': appointments})

def edit3(request, app_id):
    appointmentt = appointment.objects.get(app_id=app_id)
    return render(request,"edit3.html",{'appointmentt' : appointmentt})

def update3(request, app_id):
    apointmentt = appointment.objects.get(app_id=app_id)
    form = appointmentForm(request.POST, instance = appointmentt)
    if form.is_valid():
        form.save()
        return redirect('/show3')
    return render(request,"edit3.html",{'appointmentt' : appointmentt})
def delete3(request, app_id):
    appointmentt = appointment.objects.get(app_id=app_id)
    appointmentt.delete()
    return redirect("/show3")

#bill_____________________________________________________________________________________________________

def bi(request):
    if request.method == "POST":
        form = billForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                return redirect("/show4")
            except:
                pass
    else:
        form = billForm()
        return render(request,"bill.html",{'form':form})

def show4(request):
    bills = bill.objects.all()
    return render(request,"show4.html",{'bills': bills})

def edit4(request, invoice):
    billt = bill.objects.get(invoice=invoice)
    return render(request,"edit4.html",{'billt' : billt})

def update4(request, invoice):
    billt = bill.objects.get(invoice=invoice)
    form = billForm(request.POST, instance = billt)
    if form.is_valid():
        form.save()
        return redirect('/show4')
    return render(request,"edit4.html",{'billt' : billt})
def delete4(request, invoice):
    billt = bill.objects.get(invoice=invoice)
    billt.delete()
    return redirect("/show4")