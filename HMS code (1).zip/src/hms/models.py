
from django.db import models
from django.utils import timezone
from decimal import Decimal
# Create your models here.
class department(models.Model):
    dept_type=models.CharField(max_length=30)
    dept_incharge=models.CharField(max_length=30)
    dept_cabin=models.IntegerField(primary_key=True) 
    demail_id=models.EmailField(max_length=100)
    class Meta:
        db_table="department"

class patient(models.Model):
    full_name=models.CharField(max_length=30)
    patient_id=models.AutoField(primary_key=True)
    age=models.IntegerField(default=0)
    blood_group=models.CharField(max_length=30)
    gender=models.CharField(max_length=30)
    room_number=models.IntegerField(default=0)
    pemail_id=models.EmailField(max_length=100)
    address=models.CharField(max_length=30)
    check_in_date=models.DateField(default=timezone.now)
    class Meta:
        db_table="patient"

class staff(models.Model):
    s_id=models.AutoField(primary_key=True)
    s_name=models.CharField(max_length=30)
    gender=models.CharField(max_length=30)
    semail_id=models.EmailField(max_length=100)
    sal=models.IntegerField(default=0)
    exp=models.CharField(max_length=30)
    class Meta:
        db_table="staff"

class appointment(models.Model):
    app_id=models.AutoField(primary_key=True)
    patient_id=models.ForeignKey(patient, on_delete=models.CASCADE)
    date=models.DateField(default=timezone.now)
    time=models.TimeField()
    s_id=models.ForeignKey(staff, on_delete=models.CASCADE)
    notes=models.CharField(max_length=30)
    class Meta:
        db_table="appointment"


class bill(models.Model):
    invoice=models.AutoField(primary_key=True)
    date=models.DateField(default=timezone.now)
    amount_due=models.DecimalField(max_digits=10, decimal_places=2)
    class Meta:
        db_table="bill"


